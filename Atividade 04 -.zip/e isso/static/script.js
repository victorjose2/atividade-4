const API_URL = 'http://127.0.0.1:5000/produtos';

// Carregar produtos ao iniciar
document.addEventListener('DOMContentLoaded', carregarProdutos);

// Gerenciar envio do formulário
document.getElementById('form-produto').addEventListener('submit', async (e) => {
    e.preventDefault();
    
    const produto = {
        nome: document.getElementById('nome').value,
        quantidade: parseInt(document.getElementById('quantidade').value)
    };

    const id = document.getElementById('produto-id').value;

    if (id) {
        await atualizarProduto(id, produto);
    } else {
        await adicionarProduto(produto);
    }

    e.target.reset();
    carregarProdutos();
});

// Funções API
async function carregarProdutos() {
    const resposta = await fetch(API_URL);
    const produtos = await resposta.json();
    exibirProdutos(produtos);
}

async function adicionarProduto(produto) {
    await fetch(API_URL, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(produto)
    });
}

async function atualizarProduto(id, produto) {
    await fetch(`${API_URL}/${id}`, {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(produto)
    });
}

async function excluirProduto(id) {
    if (confirm('Tem certeza que deseja excluir este produto?')) {
        await fetch(`${API_URL}/${id}`, { method: 'DELETE' });
        carregarProdutos();
    }
}

// Preencher formulário para edição
function editarProduto(id, nome, quantidade) {
    document.getElementById('produto-id').value = id;
    document.getElementById('nome').value = nome;
    document.getElementById('quantidade').value = quantidade;
}

// Exibir produtos na tabela
function exibirProdutos(produtos) {
    const tabela = document.getElementById('tabela-produtos');
    tabela.innerHTML = produtos.map(produto => `
        <tr>
            <td>${produto.id}</td>
            <td>${produto.nome}</td>
            <td>${produto.quantidade}</td>
            <td>
                <button class="btn-editar" onclick="editarProduto(${produto.id}, '${produto.nome}', ${produto.quantidade})">
                    Editar
                </button>
                <button class="btn-excluir" onclick="excluirProduto(${produto.id})">
                    Excluir
                </button>
            </td>
        </tr>
    `).join('');
}