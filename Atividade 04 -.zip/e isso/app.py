from flask import Flask, render_template, request, jsonify, send_file
import sqlite3
import os
from flask_cors import CORS

app = Flask(__name__)
CORS(app)

# Função para conectar ao banco de dados
def get_db_connection():
    conn = sqlite3.connect('banco.db')
    conn.row_factory = sqlite3.Row
    return conn

# Criar tabela se não existir
def criar_tabela():
    conn = get_db_connection()
    conn.execute('''
        CREATE TABLE IF NOT EXISTS produtos (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            nome TEXT NOT NULL,
            quantidade INTEGER NOT NULL
        )
    ''')
    conn.commit()
    conn.close()

# Rota principal - serve o frontend
@app.route('/')
def index():
    return send_file('index.html')

# GET - Listar todos os produtos
@app.route('/produtos', methods=['GET'])
def listar_produtos():
    conn = get_db_connection()
    produtos = conn.execute('SELECT * FROM produtos').fetchall()
    conn.close()
    
    # Converter para lista de dicionários
    produtos_list = []
    for produto in produtos:
        produtos_list.append({
            'id': produto['id'],
            'nome': produto['nome'],
            'quantidade': produto['quantidade']
        })
    
    return jsonify(produtos_list)

# POST - Adicionar novo produto
@app.route('/produtos', methods=['POST'])
def adicionar_produto():
    dados = request.get_json()
    
    if not dados or 'nome' not in dados or 'quantidade' not in dados:
        return jsonify({'erro': 'Dados incompletos'}), 400
    
    nome = dados['nome']
    quantidade = dados['quantidade']
    
    conn = get_db_connection()
    conn.execute('INSERT INTO produtos (nome, quantidade) VALUES (?, ?)', 
                (nome, quantidade))
    conn.commit()
    conn.close()
    
    return jsonify({'mensagem': 'Produto adicionado com sucesso!'}), 201

# PUT - Atualizar produto
@app.route('/produtos/<int:id>', methods=['PUT'])
def atualizar_produto(id):
    dados = request.get_json()
    
    if not dados or 'nome' not in dados or 'quantidade' not in dados:
        return jsonify({'erro': 'Dados incompletos'}), 400
    
    nome = dados['nome']
    quantidade = dados['quantidade']
    
    conn = get_db_connection()
    resultado = conn.execute('UPDATE produtos SET nome = ?, quantidade = ? WHERE id = ?', 
                           (nome, quantidade, id))
    conn.commit()
    conn.close()
    
    if resultado.rowcount == 0:
        return jsonify({'erro': 'Produto não encontrado'}), 404
    
    return jsonify({'mensagem': 'Produto atualizado com sucesso!'})

# DELETE - Excluir produto
@app.route('/produtos/<int:id>', methods=['DELETE'])
def excluir_produto(id):
    conn = get_db_connection()
    resultado = conn.execute('DELETE FROM produtos WHERE id = ?', (id,))
    conn.commit()
    conn.close()
    
    if resultado.rowcount == 0:
        return jsonify({'erro': 'Produto não encontrado'}), 404
    
    return jsonify({'mensagem': 'Produto excluído com sucesso!'})

if __name__ == '__main__':
    criar_tabela()
    app.run(debug=True, host='127.0.0.1', port=5000)